synthetic fixture (not real data)
A = Bark
B = Whine
