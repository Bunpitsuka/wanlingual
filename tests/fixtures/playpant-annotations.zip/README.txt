synthetic fixture (not real data)
